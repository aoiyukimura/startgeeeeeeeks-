<?php
namespace Concrete\Core\Gathering\Item\Template\Tile;

class Template extends \Concrete\Core\Gathering\Item\Template\Template
{
    public function gatheringItemTemplateControlsSlotDimensions()
    {
        return true;
    }
}
