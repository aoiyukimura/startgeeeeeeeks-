<?php
namespace Concrete\Core\Gathering\Item\Template\Detail;

class Template extends \Concrete\Core\Gathering\Item\Template\Template
{
    public function gatheringItemTemplateControlsSlotDimensions()
    {
        return false;
    }
}
