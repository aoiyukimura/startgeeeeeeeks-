<?php
namespace Concrete\Core\Package;

interface LocalizablePackageInterface
{

    function getTranslationFile($locale);

}
