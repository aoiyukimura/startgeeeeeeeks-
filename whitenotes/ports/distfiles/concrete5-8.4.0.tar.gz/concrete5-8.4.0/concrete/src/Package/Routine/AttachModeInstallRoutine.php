<?php
namespace Concrete\Core\Package\Routine;

use Concrete\Core\Package\StartingPointInstallRoutine;

class AttachModeInstallRoutine extends StartingPointInstallRoutine implements AttachModeCompatibleRoutineInterface
{
}
