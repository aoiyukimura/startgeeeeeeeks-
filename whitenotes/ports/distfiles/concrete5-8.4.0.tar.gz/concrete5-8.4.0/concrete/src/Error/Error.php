<?php
namespace Concrete\Core\Error;

use Concrete\Core\Error\ErrorList\ErrorList;

/**
 * @deprecated
 */
class Error extends ErrorList
{


}
