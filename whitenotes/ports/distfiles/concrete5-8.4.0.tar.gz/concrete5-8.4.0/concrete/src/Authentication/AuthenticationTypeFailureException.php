<?php
namespace Concrete\Core\Authentication;

class AuthenticationTypeFailureException extends \Exception
{
}
