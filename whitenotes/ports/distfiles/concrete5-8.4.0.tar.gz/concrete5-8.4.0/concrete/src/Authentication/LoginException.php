<?php
namespace Concrete\Core\Authentication;

class LoginException extends \Exception
{
}
