<?php
namespace Concrete\Core\Block;

class CoreAreaLayoutCustomStyle extends CustomStyle
{
}
