<?php
namespace Concrete\Core\Conversation\Message;

use Concrete\Core\Foundation\ConcreteObject;

class Rating extends ConcreteObject
{
}
