<?php
namespace Concrete\Core\Permission\Access;

class MarketplaceNewsflowAccess extends Access
{
}
