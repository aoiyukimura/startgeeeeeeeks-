<?php
namespace Concrete\Core\Permission\Registry\Entry;

interface EntrySubjectInterface
{


}
