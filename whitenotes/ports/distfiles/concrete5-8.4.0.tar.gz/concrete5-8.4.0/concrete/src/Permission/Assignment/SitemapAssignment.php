<?php
namespace Concrete\Core\Permission\Assignment;

class SitemapAssignment extends Assignment
{
}
