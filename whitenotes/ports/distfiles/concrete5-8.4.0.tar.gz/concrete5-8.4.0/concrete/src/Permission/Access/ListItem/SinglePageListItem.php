<?php
namespace Concrete\Core\Permission\Access\ListItem;

class SinglePageListItem extends PageListItem
{
}
