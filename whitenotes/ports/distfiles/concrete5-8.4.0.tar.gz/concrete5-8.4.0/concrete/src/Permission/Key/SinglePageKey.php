<?php
namespace Concrete\Core\Permission\Key;

class SinglePageKey extends PageKey
{
}
