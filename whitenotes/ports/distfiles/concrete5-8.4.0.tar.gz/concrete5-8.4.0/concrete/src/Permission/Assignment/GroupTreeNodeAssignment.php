<?php
namespace Concrete\Core\Permission\Assignment;

class GroupTreeNodeAssignment extends TreeNodeAssignment
{
}
