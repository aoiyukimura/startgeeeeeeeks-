<?php
namespace Concrete\Core\Permission\Access;

use Concrete\Core\Site\SiteAggregateInterface;

interface SiteAccessInterface extends SiteAggregateInterface
{
    
}