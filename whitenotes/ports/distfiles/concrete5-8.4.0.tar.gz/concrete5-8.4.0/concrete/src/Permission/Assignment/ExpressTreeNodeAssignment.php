<?php
namespace Concrete\Core\Permission\Assignment;

class ExpressTreeNodeAssignment extends TreeNodeAssignment
{
}
