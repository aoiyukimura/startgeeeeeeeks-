<?php
namespace Concrete\Core\Permission\Access;

class GatheringAccess extends Access
{
}
