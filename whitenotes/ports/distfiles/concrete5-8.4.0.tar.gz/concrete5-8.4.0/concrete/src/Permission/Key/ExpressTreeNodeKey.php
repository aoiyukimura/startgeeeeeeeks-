<?php
namespace Concrete\Core\Permission\Key;

class ExpressTreeNodeKey extends TreeNodeKey
{
}
