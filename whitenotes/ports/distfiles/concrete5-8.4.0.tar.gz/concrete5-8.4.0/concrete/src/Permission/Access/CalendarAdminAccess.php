<?php
namespace Concrete\Core\Permission\Access;

class CalendarAdminAccess extends Access
{
}
