<?php
namespace Concrete\Core\Permission\Assignment;

class SinglePageAssignment extends PageAssignment
{
}
