<?php
namespace Concrete\Core\Permission\Key;

class UserKey extends Key
{
}
