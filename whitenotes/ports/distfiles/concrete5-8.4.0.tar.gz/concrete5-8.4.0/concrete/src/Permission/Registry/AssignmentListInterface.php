<?php
namespace Concrete\Core\Permission\Registry;

interface AssignmentListInterface
{

    /**
     * @return AssignmentInterface[]
     */
    public function getAssignments();

    

}