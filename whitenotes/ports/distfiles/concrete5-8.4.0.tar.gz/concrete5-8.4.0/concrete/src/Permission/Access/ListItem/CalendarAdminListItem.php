<?php
namespace Concrete\Core\Permission\Access\ListItem;

class CalendarAdminListItem extends ListItem
{
}
