<?php
namespace Concrete\Core\Permission\Access\ListItem;

class ExpressTreeNodeListItem extends TreeNodeListItem
{
}
