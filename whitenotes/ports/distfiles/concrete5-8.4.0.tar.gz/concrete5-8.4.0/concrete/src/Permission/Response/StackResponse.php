<?php
namespace Concrete\Core\Permission\Response;

class StackResponse extends PageResponse
{
}
