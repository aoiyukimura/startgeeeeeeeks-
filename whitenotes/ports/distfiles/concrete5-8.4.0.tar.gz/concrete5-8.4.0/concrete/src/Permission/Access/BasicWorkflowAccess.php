<?php
namespace Concrete\Core\Permission\Access;

class BasicWorkflowAccess extends WorkflowAccess
{
}
