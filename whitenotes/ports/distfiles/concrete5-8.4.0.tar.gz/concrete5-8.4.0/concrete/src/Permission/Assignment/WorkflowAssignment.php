<?php
namespace Concrete\Core\Permission\Assignment;

class WorkflowAssignment extends Assignment
{
}
