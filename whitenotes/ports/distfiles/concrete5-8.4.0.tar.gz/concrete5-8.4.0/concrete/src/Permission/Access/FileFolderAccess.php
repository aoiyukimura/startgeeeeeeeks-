<?php
namespace Concrete\Core\Permission\Access;

class FileFolderAccess extends TreeNodeAccess
{
}
