<?php
namespace Concrete\Core\Permission\Key;

use PermissionKey;

class BlockTypeKey extends PermissionKey
{
}
