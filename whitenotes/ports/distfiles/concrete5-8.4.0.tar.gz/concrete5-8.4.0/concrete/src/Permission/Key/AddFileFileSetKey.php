<?php
namespace Concrete\Core\Permission\Key;

/**
 * @deprecated
 */
class AddFileFileSetKey extends Key
{

}
