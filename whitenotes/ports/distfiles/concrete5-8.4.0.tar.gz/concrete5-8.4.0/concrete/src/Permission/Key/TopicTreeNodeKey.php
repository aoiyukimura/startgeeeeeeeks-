<?php
namespace Concrete\Core\Permission\Key;

class TopicTreeNodeKey extends TreeNodeKey
{
}
