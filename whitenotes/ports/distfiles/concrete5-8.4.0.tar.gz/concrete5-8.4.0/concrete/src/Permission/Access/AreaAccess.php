<?php
namespace Concrete\Core\Permission\Access;

class AreaAccess extends Access
{
}
