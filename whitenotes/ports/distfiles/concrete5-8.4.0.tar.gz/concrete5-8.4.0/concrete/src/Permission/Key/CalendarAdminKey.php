<?php
namespace Concrete\Core\Permission\Key;

class CalendarAdminKey extends Key
{
}
