<?php
namespace Concrete\Core\Permission\Access\ListItem;

class GatheringListItem extends ListItem
{
}
