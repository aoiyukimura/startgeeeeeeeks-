<?php
namespace Concrete\Core\Permission\Access\ListItem;

defined('C5_EXECUTE') or die("Access Denied.");
class MultilingualSectionListItem extends PageListItem
{
}
