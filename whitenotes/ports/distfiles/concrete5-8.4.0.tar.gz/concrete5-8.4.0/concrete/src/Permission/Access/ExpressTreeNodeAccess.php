<?php
namespace Concrete\Core\Permission\Access;

class ExpressTreeNodeAccess extends TreeNodeAccess
{
}
