<?php
namespace Concrete\Core\Permission\Access;

class CalendarAccess extends Access
{
}
