<?php
namespace Concrete\Core\Permission\Access\ListItem;

class UserListItem extends ListItem
{
}
