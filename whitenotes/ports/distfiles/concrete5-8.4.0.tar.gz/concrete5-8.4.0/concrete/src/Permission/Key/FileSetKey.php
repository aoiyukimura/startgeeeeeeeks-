<?php
namespace Concrete\Core\Permission\Key;

/**
 * @deprecated
 * Only here to keep errors from happening on upgrade
 */
class FileSetKey extends Key
{

}
