<?php
namespace Concrete\Core\Permission\Key;

class CategoryTreeNodeKey extends TreeNodeKey
{
}
