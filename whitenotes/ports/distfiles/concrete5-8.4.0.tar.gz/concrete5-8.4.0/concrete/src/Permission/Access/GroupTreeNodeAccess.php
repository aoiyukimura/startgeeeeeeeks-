<?php
namespace Concrete\Core\Permission\Access;

class GroupTreeNodeAccess extends TreeNodeAccess
{
}
